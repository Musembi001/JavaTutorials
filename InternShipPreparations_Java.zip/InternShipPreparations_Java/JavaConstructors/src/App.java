public class App {
    int x;
    int z;
    int modelYear;
    String modelName;
    public App(){
        x=5;
    }

    public App(int y){

        x=y;

    }

    public App(int year, String name){
        modelYear=year;
        modelName=name;
    }
    public static void main(String[] args) throws Exception {
        App myObj=new App();
        System.out.println(myObj.x);
        App myObj2=new App(18);
        System.out.println(myObj2.x);
        App myObj3=new App(2021,"Mustang");
        App myObj4=new App(2023,"Volvo");
        System.out.println(myObj3.modelYear+" "+myObj3.modelName);
        System.out.println(myObj4.modelYear+" "+myObj4.modelName);

    }
}
