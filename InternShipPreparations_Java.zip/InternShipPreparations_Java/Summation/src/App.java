public class App {
    public static void main(String[] args) throws Exception {
        int x=56;
        int y=9789;
        double randomNum=(Math.random()*101);
        int time=20;
        String result=(time<18)?"Good day": "Good evening";
        System.out.println(result);
        if(time<18){
            System.out.println("Good day");
        }else{
            System.out.println("Good evening");
        }
        System.out.println(randomNum);
        System.out.println(Math.max(x, y));
        System.out.println(x+y);
        System.out.println(Math.abs(-4.7));
        String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        txt.indexOf("J");
        System.out.println(txt.indexOf("J"));
        System.out.println("The length of the txt string is: " + txt.length());
    }
}
