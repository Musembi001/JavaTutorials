public class App {
    
    public void fizzBuzz(){
        for(int i = 0; i < 51; i++){
            if(i%3==0 && i%5==0){
                System.out.println("FizzBuzz");
    
            }else if(i%3==0){
                System.out.println("Fizz");
            }else if(i%5==0){
                System.out.println("Buzz");
            }else{
                System.out.println(i);
            }
            
        }
        
    }

    public static int findsecondLargest(int [] arr){
        if(arr==null ||arr.length<2){
            throw new IllegalArgumentException("null or less than 2 elements");
        }
        int largest=Integer.MIN_VALUE;
        int seccondLargest=Integer.MIN_VALUE;
        for(int i=0;i<arr.length;i++){
            if (arr[i]>largest){
                seccondLargest=largest;
                largest=arr[i];
            } 
        
        }
        
    }

    
    public static void main(String[] args) throws Exception {
        App myObj1=new App();
        myObj1.fizzBuzz();
        Person myObj=new Person();
        myObj.setName("Musembi");
        System.out.println(myObj.getName());
    }
}

