package com.static_and_public_methods;

public class Main {

    static void myStaticMethod(){
        System.out.println("Static methods can be called without creating objcets of the class");
    }
    public void myPublicMethod(){
        System.out.println("Public methods must be called by creating an object of the class");
    }
    public static void main(String[] args) {
        myStaticMethod();//calling static method
        Main myObj=new Main();//creating and object  of the class which is public inorder to use its method
        myObj.myPublicMethod();//CALLING THE public methodnon the object
    }
}