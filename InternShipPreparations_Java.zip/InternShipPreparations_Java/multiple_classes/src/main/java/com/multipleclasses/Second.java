package com.multipleclasses;

public class Second {
    int x=56;
}
