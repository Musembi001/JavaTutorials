package com.multipleclasses;

public class Main {
    public static void main(String[] args) {
        Second myNewObj=new Second();
        Second myNewObj1=new Second();
        System.out.println(myNewObj.x);
        System.out.println(myNewObj1.x);
    }
}