public class App {
    public static void main(String[] args) throws Exception {
        // System.out.println("Hello, World!");
        String first_name="Musembi";
        String last_name="Makite";
        System.out.println("Hello "+first_name+" "+last_name);
        System.out.printf("Hello %s %s", first_name,last_name);
    }
}
