package com.abstractclasses_and_objects;

//abstract Class
abstract class Second{
    //Abstract method has no body
    public String fname;
    public int age;
    // public Second(){
    //     fname="John";
    //     age=24;
    // }
    public abstract void study();//abstract method
}

class Student extends Second{
    public int graduationYear=2025;

    public Student(){
        fname="John";
        age=24;
    }
    public void study(){
        System.out.println("Studying all day long");//body of the abtract method has been implemented here

    }
}



public class Main {
    public static void main(String[] args) {
        Student myObj=new Student();
        System.out.println("Name: "+myObj.fname);
        System.out.println("Age:"+myObj.age);
        System.out.println("Graduation Year: "+myObj.graduationYear);
    }
}