

public class App {

    static int myMethod(int x,int y){
        int result=x+y;
        return result;
    }

    static void myMethod(){
        System.out.println("I just got excuted!");
    }
    public static void main(String[] args) throws Exception {
        myMethod();
        myMethod(6,7);
        System.out.println("Summation= "+myMethod(9, 10));
    }
}
