public class App {
    public static void main(String[] args) throws Exception {
        String [] books={"java","python","c++","c#"};// single dimentional arrays
        int [] numbers={1,2,3,4,5,6,7,8,9,10};

        int [] ages={20,22,18,35,48,26,87,70};
        float avg,sum=0;
        int length=ages.length;

        for(int age: ages){
            sum += age;
            System.out.println("Sum of the ages is: "+sum);
        }
        avg=sum/length;
        System.out.println("Average: "+avg);
//for loops
        for(int i=0;i<=numbers.length;i++){
            System.out.println(numbers[i]);
        }
        for(int i: numbers){
            System.out.println(i);

        }
        System.out.println(numbers[2]);
        System.out.println(numbers.length);
        // System.out.println(numbers);
        System.out.println("Books in the library are:"+books[0]+","+books[1]+","+books[2]+","+books[3]);
    }
}
