package com.recursion;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello");
        double result=sum(10);
        System.out.println(result);
    }

    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }
}
