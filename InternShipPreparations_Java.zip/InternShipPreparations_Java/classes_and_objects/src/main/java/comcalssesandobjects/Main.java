package comcalssesandobjects;

public class Main {
    int x=56;
    public static void main(String[] args) {
        //Creating Objects
        Main myObj=new Main();
        Main myObj2=new Main();
        Main myObj3=new Main();
        System.out.println(myObj2.x);
        System.out.println(myObj.x);
        System.out.println(myObj3.x);
    }
}