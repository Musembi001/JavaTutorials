package com.multid_arrays;

public class Main {
    public static void main(String[] args) {
        // System.out.println("Hello world!");
        int [][] myNumbers= {{1,2,4,5},{3,6,7}};
        // int[][] matrix;
        // matrix = new int[3][3];
        int matrix[][]={{1, 2, 3},{4, 5, 6},{7, 8, 9}};
        System.out.println(matrix[2][0]); // Output: 6

        for(int i=0;i<matrix.length;i++){
            for(int j=0;j<matrix[i].length;j++){
                System.out.println(matrix[i][j]+ " ");
            }

        }

    }
}