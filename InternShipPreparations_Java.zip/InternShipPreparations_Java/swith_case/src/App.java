import java.util.Scanner;

public class App {

    public static void main(String[] args) throws Exception {
        Scanner Input=new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = Input.nextLine();

        name=Input.nextLine();
        System.out.println("Enter the day Number kindly: ");
        int day=Input.nextInt();
        switch(day){
            case 1:System.out.println("Monday");break;
            case 2:System.out.println("Tuesday");break;
            case 3:System.out.println("Wednesday");break;
            case 4:System.out.println("Tursday");break;
            case 5:System.out.println("Friday");break;
            case 6:System.out.println("Saturday");break;
            case 7:System.out.println("Sunday");break;
            default:System.out.println("Invalid day");break;
        }
        System.out.printf("Hello %s ",name +"You selected day "+day+"th day of the week");
    }
}
