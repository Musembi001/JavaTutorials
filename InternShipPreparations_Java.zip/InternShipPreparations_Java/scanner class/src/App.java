import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter your name:");
        String name=in.nextLine();
        System.out.println("Hello, "+name+"!");

        // System.out.println("Hello, World!");
    }
}
